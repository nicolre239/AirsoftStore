create definer = root@localhost trigger after_update_parking
    after UPDATE
    on parking
    for each row
BEGIN 
IF OLD.Street_idStreet <> NEW.Street_idStreet THEN
  UPDATE Street SET count_parking = count_parking + 1 WHERE id_street=NEW.Street_idStreet;
  UPDATE Street SET count_parking = count_parking - 1 WHERE id_street=OLD.Street_idStreet;
END IF;
END;

