create definer = root@localhost trigger after_insert_parking
    after INSERT
    on parking
    for each row
BEGIN 
UPDATE Street SET count_parking = count_parking + 1 WHERE id_street=NEW.Street_idStreet;
END;

