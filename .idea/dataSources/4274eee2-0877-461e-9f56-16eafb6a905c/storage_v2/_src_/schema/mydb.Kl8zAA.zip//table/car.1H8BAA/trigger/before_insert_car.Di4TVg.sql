create definer = root@localhost trigger before_insert_car
    before INSERT
    on car
    for each row
BEGIN
 IF EXISTS (SELECT * FROM car WHERE car.number = NEW.number) THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = "Ошибка. Автомобиль с таким номером уже существует.";
  END IF;
END;

