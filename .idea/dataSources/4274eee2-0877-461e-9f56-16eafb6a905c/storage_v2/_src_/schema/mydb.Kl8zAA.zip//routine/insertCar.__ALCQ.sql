create
    definer = root@localhost procedure insertCar(IN carNumber varchar(15), IN carType varchar(50), IN ownerID int)
BEGIN
	DECLARE typeID INT;
	SELECT id_type into typeID from CarType WHERE name_of_type = carType;
	IF typeID IS NULL THEN
		INSERT INTO CarType (name_of_type) values(carType);
        select last_insert_id() into typeId;
	END IF;
	INSERT INTO Car (number, CarType_id_type, CarOwner_id_owner) VALUES
	(carNumber, typeId, 1);
END;

