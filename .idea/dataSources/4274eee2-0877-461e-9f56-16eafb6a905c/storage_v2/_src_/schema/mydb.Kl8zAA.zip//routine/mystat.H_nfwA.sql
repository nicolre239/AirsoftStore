create
    definer = root@localhost procedure mystat()
BEGIN
	create temporary table if not exists temp
	SELECT street.id_street, street.street_name, count(id_parking) as parking_count
    FROM parking RIGHT JOIN street ON parking.Street_idStreet = street.id_street
    GROUP BY id_street;
    
    SELECT temp.* from temp;
    
	drop table temp;
END;

