create
    definer = root@localhost function getEarliest() returns datetime
BEGIN
	DECLARE entryDate DATETIME;
	SELECT  max(entry_time) into entryDate FROM Registration;
    RETURN (entryDate);
END;

