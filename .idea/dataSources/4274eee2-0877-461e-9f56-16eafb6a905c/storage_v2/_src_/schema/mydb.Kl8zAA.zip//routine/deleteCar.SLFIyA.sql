create
    definer = root@localhost procedure deleteCar(IN idCar int)
BEGIN
	DELETE FROM registration WHERE Car_id_car = idCar;
	DELETE FROM Car
	WHERE  id_car = idCar;
END;

