create definer = root@localhost trigger before_delete_street
    before DELETE
    on street
    for each row
BEGIN
  IF EXISTS (SELECT * FROM parking WHERE Street_idStreet = OLD.id_street) THEN
  SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = "Ошибка. Есть парковки, связанные с удаляемой улицей.";
  END IF;
END;

