create definer = root@localhost trigger before_update_car
    before UPDATE
    on car
    for each row
BEGIN
  IF EXISTS (SELECT * FROM car WHERE car.number = NEW.number AND OLD.number <> NEW.number) THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = "Ошибка. Автомобиль с таким номером уже существует.";
  END IF;
END;

