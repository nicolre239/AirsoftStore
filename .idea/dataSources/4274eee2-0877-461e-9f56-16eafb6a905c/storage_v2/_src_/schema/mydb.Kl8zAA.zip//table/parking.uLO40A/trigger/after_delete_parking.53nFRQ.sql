create definer = root@localhost trigger after_delete_parking
    after DELETE
    on parking
    for each row
BEGIN 
UPDATE Street SET count_parking = count_parking - 1 WHERE id_street=OLD.Street_idStreet;
END;

