create
    definer = root@localhost procedure deleteReg(IN idReg int)
BEGIN
	declare carID int;
	SELECT Car_id_car  INTO carID FROM Registration WHERE id_reg = idReg;

	DELETE FROM registration WHERE id_reg = idReg;

DELETE FROM Car
WHERE  car.id_car = carID AND Car.id_car NOT IN (SELECT Car_id_car FROM registration);
END;

